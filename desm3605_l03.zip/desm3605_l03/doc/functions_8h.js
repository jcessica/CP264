var functions_8h =
[
    [ "STRING_BIG", "functions_8h.htm#a8ac218a60b85b3029135a4c4e1e8687e", null ],
    [ "STRING_SMALL", "functions_8h.htm#adb4e69483705ac69a614ed513bb9370f", null ],
    [ "int_array_read", "functions_8h.htm#a1ad7ad3a9cf20cef4b7fff06d71878c7", null ],
    [ "sum_integers", "functions_8h.htm#a72fae787ac54c7a4ea16747705c9ea94", null ],
    [ "sum_three_integers", "functions_8h.htm#add7953d987bb6f7a67917e9811d19514", null ]
];