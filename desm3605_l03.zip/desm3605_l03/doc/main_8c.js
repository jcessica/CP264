var main_8c =
[
    [ "STRING_SIZE", "main_8c.htm#ad78224efe1d3fb39b67ca74ad9d9eec7", null ],
    [ "main", "main_8c.htm#a700a0caa5b70a06d1064e576f9f3cf65", null ]
];